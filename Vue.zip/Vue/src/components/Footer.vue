<template>
    <div class="bg-gray-50 text-gray-500  w-full h-10 flex items-center justify-end font-semibold ">
        <h1 class="mx-10" dir="rtl">&copy; &nbsp; معاونیت علمی &nbsp;{{ new Date().getFullYear() }}</h1>
    </div>
</template>
