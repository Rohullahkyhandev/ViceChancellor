<template>
    <aside class="bg-indigo-900  w-64 hidden  sm:block">
                        <div class="flex items-center justify-center  py-2 bg-indigo-800">
                            <img src="../../public/logo.PNG" class="w-16" alt="">
                       </div>
                    <nav class="flex items-start justify-start flex-col">
                            <p class="font-semibold  text-gray-500 text-start mt-2 w-full px-3">پنل مدیریت</p>
                    <ul class="mt-3 w-full">
                        <li class="hover:bg-gray-400 transition-colors cursor-pointer w-full px-3 py-2   text-white">
                            <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                <svg class="fill-stroke h-5 w-5" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M9 4H5C4.44772 4 4 4.44772 4 5V9C4 9.55228 4.44772 10 5 10H9C9.55228 10 10 9.55228 10 9V5C10 4.44772 9.55228 4 9 4Z"
                                        stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path
                                        d="M19 4H15C14.4477 4 14 4.44772 14 5V9C14 9.55228 14.4477 10 15 10H19C19.5523 10 20 9.55228 20 9V5C20 4.44772 19.5523 4 19 4Z"
                                        stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path
                                        d="M9 14H5C4.44772 14 4 14.4477 4 15V19C4 19.5523 4.44772 20 5 20H9C9.55228 20 10 19.5523 10 19V15C10 14.4477 9.55228 14 9 14Z"
                                        stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path
                                        d="M19 14H15C14.4477 14 14 14.4477 14 15V19C14 19.5523 14.4477 20 15 20H19C19.5523 20 20 19.5523 20 19V15C20 14.4477 19.5523 14 19 14Z"
                                        stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span>داشبورد</span>
                            </router-link>
                        </li>
                        <li v-if="admin"
                            class="hover:bg-gray-400 mt-3 transition-colors cursor-pointer w-full px-4 py-2  text-white">
                                            <router-link :to="{ name: 'app.user.list' }" class="flex items-center justify-start gap-3">
                                            <svg class="fill-stroke w-5 h-5" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"
                                                    stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path
                                                    d="M6 21V19C6 17.9391 6.42143 16.9217 7.17157 16.1716C7.92172 15.4214 8.93913 15 10 15H14C15.0609 15 16.0783 15.4214 16.8284 16.1716C17.5786 16.9217 18 17.9391 18 19V21"
                                                    stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            <span>استفاده کننده ها</span>
                                        </router-link>
                                    </li>
                                    <li class="hover:bg-gray-400 transition-colors mt-3 cursor-pointer w-full px-4 py-2   text-white">
                                        <router-link to="#" class="flex items-center justify-start gap-3" @click="togglePdc">
                                            <svg id="icon1"
                                                :class="[pdcToggle == true ? 'rotate-180 transform w-5 h-5 transition' : 'transform w-5 h-5']"
                                                width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                            <span>آمریت P.D.C</span>
                                        </router-link>
                                        <ul class="mt-3 mr-3 transition-all" v-if="pdcToggle">
                                            <li class="mb-2 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.pdc.documents' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http:/www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                                                    </svg>
                                                    <span>مکتوب ها</span>
                                                </router-link>
                                            </li>
                                            <li class="mt-3 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.pdc.plan.list' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http:/www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                                                    </svg>
                                                    <span>پلان ها</span>
                                                </router-link>
                                            </li>
                                            <li class="mt-3 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                                                    </svg>
                                                    <span>کمیته ها</span>
                                                </router-link>
                                            </li>
                                            <li class="mt-3 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3 ">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5M9 11.25v1.5M12 9v3.75m3-6v6" />
                                                    </svg>
                                                    <span>ورکشاپ ها</span>
                                                </router-link>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="hover:bg-gray-400 transition-colors cursor-pointer mt-3 w-full px-3 py-2   text-white">
                                        <router-link to="#" class="flex items-center justify-start gap-3" @click="toggleTeacher">
                                            <svg id="icon1"
                                                :class="[teacherToggle == true ? 'rotate-180 transform w-5 h-5 transition' : 'transform w-5 h-5']"
                                                width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                            <span>آمریت استادان</span>
                                        </router-link>
                                        <ul class="mt-3 mr-3 transition-all" v-if="teacherToggle">
                                            <li class="mb-2 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.teacher.list' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                                                    </svg>
                                                    <span>استادان</span>
                                                </router-link>
                                            </li>
                                            <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.faculty.list' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 12V10.332A48.36 48.36 0 0 0 12 9.75c-2.551 0-5.056.2-7.5.582V21M3 21h18M12 6.75h.008v.008H12V6.75Z" />
                                                    </svg>
                                                    <span>فاکولته ها</span>
                                                </router-link>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="hover:bg-gray-400 mt-3 transition-colors cursor-pointer w-full px-3 py-2   text-white">
                                        <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3"
                                            @click="toggleQuality">
                                            <svg id="icon3"
                                                :class="[qualityToggle == true ? 'rotate-180 transform w-5 h-5 transition' : 'transform w-5 h-5']"
                                                width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                            <span>آمریت تضمین کیفیت</span>
                                        </router-link>
                                        <ul class="mt-3 mr-3 transition-all" v-if="qualityToggle">

                                            <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M3.75 12h16.5m-16.5 3.75h16.5M3.75 19.5h16.5M5.625 4.5h12.75a1.875 1.875 0 0 1 0 3.75H5.625a1.875 1.875 0 0 1 0-3.75Z" />
                                                    </svg>
                                                    <span>معیارات اصلی</span>
                                                </router-link>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="hover:bg-gray-400 mt-3 transition-colors cursor-pointer w-full px-3 py-2   text-white">
                                        <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3"
                                            @click="togglePost">
                                            <svg id="icon4"
                                                :class="[postToggle == true ? 'rotate-180 transform w-5 h-5 transition' : 'transform w-5 h-5']"
                                                width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                            <span>آمریت فوق لیسانس </span>
                                        </router-link>
                                        <ul class="mt-3 mr-3 transition-all" v-if="postToggle">

                                            <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                        stroke="currentColor" class="w-5 h-5">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                                                    </svg>
                                                    <span>استادان</span>
                                                </router-link>
                                            </li>

                                            <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                                                    <router-link :to="{ name: 'app.student.list' }" class="flex items-center justify-start gap-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.62 48.62 0 0 1 12 20.904a48.62 48.62 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.636 50.636 0 0 0-2.658-.813A59.906 59.906 0 0 1 12 3.493a59.903 59.903 0 0 1 10.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.717 50.717 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
                                </svg>

                                <span>محصلین</span>
                            </router-link>
                        </li>

                        <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                            <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.62 48.62 0 0 1 12 20.904a48.62 48.62 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.636 50.636 0 0 0-2.658-.813A59.906 59.906 0 0 1 12 3.493a59.903 59.903 0 0 1 10.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.717 50.717 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
                                </svg>

                                <span>کمیته ها</span>
                            </router-link>
                        </li>
                    </ul>
                </li>

                <li class="hover:bg-gray-400 mt-3 transition-colors cursor-pointer w-full px-3 py-2   text-white">
                    <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3"
                        @click="toggleResearch">
                        <svg id="icon5"
                            :class="[researchToggle == true ? 'rotate-180 transform w-5 h-5 transition' : 'transform w-5 h-5']"
                            viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        <span>آمریت تحقیقات علمی</span>
                    </router-link>
                    <ul class="mt-3 mr-3 transition-all" v-if="researchToggle">

                        <li class="mt-2 hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                            <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v16.5c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Zm3.75 11.625a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                                </svg>
                                <span>تحقیقات استادان</span>
                            </router-link>
                        </li>

                        <li class="mt-2  hover:bg-gray-300 transition-colors py-2 px-4 rounded">
                            <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418" />
                                </svg>

                                <span>نشرات بین المیللی</span>
                            </router-link>
                        </li>

                        <!-- <li class="mt-2">
                            <router-link :to="{ name: 'app.dashboard' }" class="flex items-center justify-start gap-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.62 48.62 0 0 1 12 20.904a48.62 48.62 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.636 50.636 0 0 0-2.658-.813A59.906 59.906 0 0 1 12 3.493a59.903 59.903 0 0 1 10.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.717 50.717 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
                                </svg>

                                <span>کمیته ها</span>
                            </router-link>
                        </li> -->
                    </ul>
                </li>
            </ul>
        </nav>

    </aside>
</template>
<script setup>
import { computed, onMounted, ref } from "vue";
import { useUserStore } from "../stores/user/userStore";

const userStore = useUserStore();

onMounted(() => {
    getCurrentPermission();
})

const admin = computed(() => userStore.permission_current.admin)


function getCurrentPermission() {
    userStore.getCurrentPermission();
}

let pdcToggle = ref(false)
let teacherToggle = ref(false)
let qualityToggle = ref(false)
let postToggle = ref(false)
let researchToggle = ref(false)




function togglePdc() {
    pdcToggle.value = !pdcToggle.value
}

function toggleTeacher() {
    teacherToggle.value = !teacherToggle.value
}


function toggleQuality() {
    qualityToggle.value = !qualityToggle.value
}


function togglePost() {
    postToggle.value = !postToggle.value
}


function toggleResearch() {
    researchToggle.value = !researchToggle.value
}

</script>
