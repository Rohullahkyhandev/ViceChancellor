<template>
    <router-link :to="{ name: 'app.dashboard' }" class="bg-blue-600 text-white font-semibold rounded py-2 px-5 ">Go
        Back</router-link>
</template>
