<template>
    <div>
        <TabHeader />
        <router-view></router-view>
    </div>
</template>

<script setup>
import TabHeader from '../pdc/index.vue'

</script>
