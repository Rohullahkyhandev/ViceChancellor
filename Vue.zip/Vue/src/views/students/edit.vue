<template>
    <h1>welcome to the edit page {{ $route.params.id }}</h1>
</template>
<script setup>

</script>
